#ifndef _KEYPAD_H
#define _KEYPAD_H

#include <Arduino.h>
#include <inttypes.h>

#define SCAN_INTERVAL_MS (20)
#define NO_KEY           ('\0')

class Keypad {
  public:
    Keypad( const char *keymap, 
      const uint8_t *rowPins, const uint8_t *colPins, 
      uint8_t numRows, uint8_t numCols );
    char  getKey();

  private:
    char * _keymap;
    uint8_t * _row_pins;
    uint8_t * _col_pins;
    uint8_t _num_rows;
    uint8_t _num_cols;
    char _prev_key;
    uint32_t _ts;
};
#endif // _KEYPAD_H