#include "Keypad.h"

Keypad::Keypad( const char *keymap, 
     const uint8_t *rowPins,
     const uint8_t *colPins, 
    uint8_t numRows, uint8_t numCols ) 
{
  _keymap   = keymap;   
  _row_pins = rowPins;
  _col_pins = colPins;  
  _num_rows = numRows;
  _num_cols = numCols;
  _prev_key = NO_KEY;
  _ts = 0;

  for ( uint8_t i=0; i < _num_rows; i++ ) {
    // enable internal pullup on input pins for R0..R3
    pinMode( _row_pins[i], INPUT_PULLUP );
  }
  for ( uint8_t i=0; i < _num_cols; i++ ) {
    uint8_t col = _col_pins[i];
    pinMode( col, OUTPUT );
    digitalWrite( col, HIGH );
  }
}

char Keypad::getKey() {
  uint32_t now = millis();
  char new_key = NO_KEY;

  if ( now - _ts >= SCAN_INTERVAL_MS ) {
    _ts = now; // saved timestamp
    // scan column by column
    for ( uint8_t c=0; c < _num_cols; c++ ) {
      for ( uint8_t i=0; i < _num_cols; i++) {
        // pull only one column to LOW, the rest to HIGH
        digitalWrite( _col_pins[i], (c==i) ? LOW : HIGH );
      }
      uint8_t row_input;
      // read the row inputs one by one
      for ( uint8_t r=0; r < _num_rows; r++) {
        row_input = digitalRead( _row_pins[r] );
        if ( row_input == 0 ) { // active
          // get the associated key char 
          new_key = _keymap[r*_num_rows + c]; 
        }
      }
      // relase the pulled-down column
      digitalWrite( _col_pins[c], HIGH );
      if ( new_key != NO_KEY ) { 
        if ( _prev_key != new_key ) {
          _prev_key = new_key;
          return new_key; // new keypress detected
        } else {
          return NO_KEY;
        }
      } 
    }
    _prev_key = new_key;
  }
  return NO_KEY;
}
