#include "mbed.h"
#include "USBSerial.h"

DigitalOut  led(LED1); // PC_13
USBSerial   serialUSB(false); // usb USB-CDC (USB-to-Serial, Full-Speed)

int main() {
    serialUSB.init();
    serialUSB.connect();

    while( !serialUSB.connected() ) {
        ThisThread::sleep_for( 10ms );
    }

    // show Mbed OS version
    serialUSB.printf( "MBed Version: %d.%d.%d\r\n", 
                    MBED_MAJOR_VERSION, 
                    MBED_MAJOR_VERSION, 
                    MBED_PATCH_VERSION );

    serialUSB.printf( "CPU frequency: %lu MHz\r\n", SystemCoreClock/1000000L );

    while (true) {
        // show the current LED status
        serialUSB.printf( "LED: %d\r\n", led.read() );
        // toggle onboard LED
        led = !led;
        // delay for 500 milliseconds
        ThisThread::sleep_for( 500ms );
    }
}
